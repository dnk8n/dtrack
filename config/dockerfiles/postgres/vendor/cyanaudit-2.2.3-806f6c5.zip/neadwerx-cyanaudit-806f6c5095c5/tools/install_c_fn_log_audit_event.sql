CREATE OR REPLACE FUNCTION cyanaudit.fn_log_audit_event()
RETURNS TRIGGER AS
 'cyanaudit.so', 'fn_log_audit_event'
LANGUAGE C;
